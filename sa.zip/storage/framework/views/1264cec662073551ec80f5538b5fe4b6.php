<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal5c77b29a2fcfa8840df69ff111ecb198 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198)): ?>
<?php $attributes = $__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198; ?>
<?php unset($__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c77b29a2fcfa8840df69ff111ecb198)): ?>
<?php $component = $__componentOriginal5c77b29a2fcfa8840df69ff111ecb198; ?>
<?php unset($__componentOriginal5c77b29a2fcfa8840df69ff111ecb198); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal1dc762f2ce942f7f71b31288216cfc8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b)): ?>
<?php $attributes = $__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b; ?>
<?php unset($__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dc762f2ce942f7f71b31288216cfc8b)): ?>
<?php $component = $__componentOriginal1dc762f2ce942f7f71b31288216cfc8b; ?>
<?php unset($__componentOriginal1dc762f2ce942f7f71b31288216cfc8b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginald3ef3bf91c913f7f4eb45956c072854e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3ef3bf91c913f7f4eb45956c072854e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.hero','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3ef3bf91c913f7f4eb45956c072854e)): ?>
<?php $attributes = $__attributesOriginald3ef3bf91c913f7f4eb45956c072854e; ?>
<?php unset($__attributesOriginald3ef3bf91c913f7f4eb45956c072854e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3ef3bf91c913f7f4eb45956c072854e)): ?>
<?php $component = $__componentOriginald3ef3bf91c913f7f4eb45956c072854e; ?>
<?php unset($__componentOriginald3ef3bf91c913f7f4eb45956c072854e); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal99a4bfc179bc691173819ea1d28e92df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99a4bfc179bc691173819ea1d28e92df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.features','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.features'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99a4bfc179bc691173819ea1d28e92df)): ?>
<?php $attributes = $__attributesOriginal99a4bfc179bc691173819ea1d28e92df; ?>
<?php unset($__attributesOriginal99a4bfc179bc691173819ea1d28e92df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99a4bfc179bc691173819ea1d28e92df)): ?>
<?php $component = $__componentOriginal99a4bfc179bc691173819ea1d28e92df; ?>
<?php unset($__componentOriginal99a4bfc179bc691173819ea1d28e92df); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal742fe0535dc0dd60734620f09441d2b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal742fe0535dc0dd60734620f09441d2b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.featured-destination','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.featured-destination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal742fe0535dc0dd60734620f09441d2b6)): ?>
<?php $attributes = $__attributesOriginal742fe0535dc0dd60734620f09441d2b6; ?>
<?php unset($__attributesOriginal742fe0535dc0dd60734620f09441d2b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal742fe0535dc0dd60734620f09441d2b6)): ?>
<?php $component = $__componentOriginal742fe0535dc0dd60734620f09441d2b6; ?>
<?php unset($__componentOriginal742fe0535dc0dd60734620f09441d2b6); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal6620d66661ae55da7e09c1cb663f78d8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6620d66661ae55da7e09c1cb663f78d8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.country-preview','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.country-preview'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6620d66661ae55da7e09c1cb663f78d8)): ?>
<?php $attributes = $__attributesOriginal6620d66661ae55da7e09c1cb663f78d8; ?>
<?php unset($__attributesOriginal6620d66661ae55da7e09c1cb663f78d8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6620d66661ae55da7e09c1cb663f78d8)): ?>
<?php $component = $__componentOriginal6620d66661ae55da7e09c1cb663f78d8; ?>
<?php unset($__componentOriginal6620d66661ae55da7e09c1cb663f78d8); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalcfeece14944421d8662f2e39429baf97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcfeece14944421d8662f2e39429baf97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.consultation-form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.consultation-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcfeece14944421d8662f2e39429baf97)): ?>
<?php $attributes = $__attributesOriginalcfeece14944421d8662f2e39429baf97; ?>
<?php unset($__attributesOriginalcfeece14944421d8662f2e39429baf97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcfeece14944421d8662f2e39429baf97)): ?>
<?php $component = $__componentOriginalcfeece14944421d8662f2e39429baf97; ?>
<?php unset($__componentOriginalcfeece14944421d8662f2e39429baf97); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginala06fe14718e51a7412cb2cd184a28b95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala06fe14718e51a7412cb2cd184a28b95 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.student-essentials','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.student-essentials'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala06fe14718e51a7412cb2cd184a28b95)): ?>
<?php $attributes = $__attributesOriginala06fe14718e51a7412cb2cd184a28b95; ?>
<?php unset($__attributesOriginala06fe14718e51a7412cb2cd184a28b95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala06fe14718e51a7412cb2cd184a28b95)): ?>
<?php $component = $__componentOriginala06fe14718e51a7412cb2cd184a28b95; ?>
<?php unset($__componentOriginala06fe14718e51a7412cb2cd184a28b95); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalbf18abedf5585b715c19d869055fa37a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbf18abedf5585b715c19d869055fa37a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbf18abedf5585b715c19d869055fa37a)): ?>
<?php $attributes = $__attributesOriginalbf18abedf5585b715c19d869055fa37a; ?>
<?php unset($__attributesOriginalbf18abedf5585b715c19d869055fa37a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf18abedf5585b715c19d869055fa37a)): ?>
<?php $component = $__componentOriginalbf18abedf5585b715c19d869055fa37a; ?>
<?php unset($__componentOriginalbf18abedf5585b715c19d869055fa37a); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mehedi/Desktop/Projects/scholarszone/resources/views/frontend/home.blade.php ENDPATH**/ ?>