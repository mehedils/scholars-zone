<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['hero' => 'hero1'   ]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['hero' => 'hero1'   ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $sliders = [
        ['title' => 'Your Gateway to Global Education', 'description' => 'Discover world-class universities and transform your future with expert guidance from Bangladesh\'s leading study abroad consultancy.', 'image' => asset('images/hero/hero1.jpg')],
        ['title' => 'Study in Top Universities Worldwide', 'description' => 'From USA to Australia, UK to Canada - we help you find the perfect destination for your academic journey.', 'image' => asset('images/hero/hero2.jpg')],
        ['title' => 'Expert Visa & Application Support', 'description' => '100% success rate with visa applications. Our experienced team handles everything from applications to interviews.', 'image' => asset('images/hero/hero3.jpg')],
    ];

?>

<?php $__env->startPush('styles'); ?>
    <style>
    .hero-slider {
        position: relative;
        overflow: hidden;
    }
    .slide {
        display: none;
        opacity: 0;
        transition: opacity 0.6s ease-in-out;
    }
    .slide.active {
        display: block;
        opacity: 1;
    }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
let currentSlideIndex = 0;
const slides = document.querySelectorAll(".slide");
const dots = document.querySelectorAll(".slider-dot");

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.classList.toggle("active", i === index);
    });
    dots.forEach((dot, i) => {
        dot.style.opacity = i === index ? "1" : "0.5";
    });
}

function nextSlide() {
    currentSlideIndex = (currentSlideIndex + 1) % slides.length;
    showSlide(currentSlideIndex);
}

function currentSlide(index) {
    currentSlideIndex = index - 1;
    showSlide(currentSlideIndex);
}

// Auto-advance slides
setInterval(nextSlide, 5000);

// Initialize first slide
showSlide(0);
</script>
<?php $__env->stopPush(); ?>


<section class="hero-slider h-[50vh] relative" id="home">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="slide h-full <?php echo e($index === 0 ? 'active' : ''); ?>">
            <div class="h-full relative">
                <div
                    class="absolute inset-0 bg-gradient-to-r from-purple-900/80 to-blue-900/60"
                ></div>
                <div
                    class="h-full bg-cover bg-center bg-no-repeat flex items-center"
                    style="background-image: url('<?php echo e($slider['image']); ?>');"
                >
                    <div
                        class="container mx-auto px-4 text-white relative z-10"
                    >
                        <div class="max-w-3xl" data-aos="fade-up">
                            <h2 class="text-5xl font-bold mb-6">
                                <?php echo e($slider['title']); ?>

                            </h2>
                            <p class="text-xl mb-8">
                                <?php echo e($slider['description']); ?>

                            </p>
                            <div class="flex space-x-4">
                                <button
                                    class="bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
                                >
                                    Get Started
                                </button>
                                <button
                                    class="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-purple-600 transition"
                                >
                                    Learn More
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Slider Controls -->
    <div
        class="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2"
    >
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button
                class="slider-dot w-3 h-3 bg-white rounded-full opacity-50 hover:opacity-100 transition"
                onclick="currentSlide(<?php echo e($index + 1); ?>)"
            ></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH /home/mehedi/Desktop/Projects/scholarszone/resources/views/components/frontend/hero.blade.php ENDPATH**/ ?>