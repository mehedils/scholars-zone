<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title><?php echo e(config('app.name', 'Scholars Zone Global')); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        />
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css"
        />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body class="bg-gray-50">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>
        <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/mehedi/scholarszone/resources/views/layouts/app.blade.php ENDPATH**/ ?>