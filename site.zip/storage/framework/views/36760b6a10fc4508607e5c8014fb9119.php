<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal5c77b29a2fcfa8840df69ff111ecb198 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198)): ?>
<?php $attributes = $__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198; ?>
<?php unset($__attributesOriginal5c77b29a2fcfa8840df69ff111ecb198); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c77b29a2fcfa8840df69ff111ecb198)): ?>
<?php $component = $__componentOriginal5c77b29a2fcfa8840df69ff111ecb198; ?>
<?php unset($__componentOriginal5c77b29a2fcfa8840df69ff111ecb198); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal1dc762f2ce942f7f71b31288216cfc8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b)): ?>
<?php $attributes = $__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b; ?>
<?php unset($__attributesOriginal1dc762f2ce942f7f71b31288216cfc8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dc762f2ce942f7f71b31288216cfc8b)): ?>
<?php $component = $__componentOriginal1dc762f2ce942f7f71b31288216cfc8b; ?>
<?php unset($__componentOriginal1dc762f2ce942f7f71b31288216cfc8b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mehedi/scholarszone/resources/views/frontend/home.blade.php ENDPATH**/ ?>