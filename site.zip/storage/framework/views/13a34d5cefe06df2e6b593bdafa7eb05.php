<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title><?php echo e(config('app.name', 'Scholars Zone Global')); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        />
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css"
        />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>

<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body class="bg-gray-50">
        <?php echo $__env->yieldContent('content'); ?>
        
        <!-- Maintenance Popup -->
        <?php if (isset($component)) { $__componentOriginal51e9dce3a09144026ede9b22aa5c1eaa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal51e9dce3a09144026ede9b22aa5c1eaa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.maintenance-popup','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.maintenance-popup'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal51e9dce3a09144026ede9b22aa5c1eaa)): ?>
<?php $attributes = $__attributesOriginal51e9dce3a09144026ede9b22aa5c1eaa; ?>
<?php unset($__attributesOriginal51e9dce3a09144026ede9b22aa5c1eaa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal51e9dce3a09144026ede9b22aa5c1eaa)): ?>
<?php $component = $__componentOriginal51e9dce3a09144026ede9b22aa5c1eaa; ?>
<?php unset($__componentOriginal51e9dce3a09144026ede9b22aa5c1eaa); ?>
<?php endif; ?>
        
        <?php echo $__env->yieldPushContent('scripts'); ?>
        <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/mehedi/Desktop/Projects/scholarszone/resources/views/layouts/app.blade.php ENDPATH**/ ?>